const express = require("express");
const cors = require("cors");
const serverless = require("serverless-http");
require("dotenv").config();

const app = express();

const allowedOrigins = [
  "http://localhost:3000",
  "http://127.0.0.1:3000",
  "https://flashfinancialsolutions.com",
];

// CORS middleware for all requests
app.use(cors({
  origin: function (origin, callback) {
    // allow requests with no origin (e.g., curl, Postman)
    if (!origin || allowedOrigins.includes(origin)) {
      callback(null, true);
    } else {
      callback(new Error("Not allowed by CORS"));
    }
  },
  credentials: true,
}));

// Explicitly handle OPTIONS preflight requests (API Gateway sometimes needs this)
app.options("*", cors({
  origin: function (origin, callback) {
    if (!origin || allowedOrigins.includes(origin)) {
      callback(null, true);
    } else {
      callback(new Error("Not allowed by CORS"));
    }
  },
  credentials: true,
}));

app.use(express.json());

console.log("JWT_SECRET:", process.env.JWT_SECRET);
console.log("DATABASE_URL:", process.env.DATABASE_URL);
console.log("Running in Lambda:", !process.env.IS_OFFLINE);

const authRoutes = require("./routes/auth");
const adminRoutes = require("./routes/admin");
const forthcrmRoutes = require("./routes/forthcrm");

app.use("/api", authRoutes);
app.use("/api/admin", adminRoutes);
app.use("/api/forthcrm", forthcrmRoutes);

// CORS-safe error handler
app.use((err, req, res, next) => {
  console.error("ERROR:", err);

  let origin = req.headers.origin;
  if (!origin || !allowedOrigins.includes(origin)) {
    origin = allowedOrigins[allowedOrigins.length - 1] || "*";
  }

  // Fix: Ensure only a single origin is sent in the header
  if (typeof origin === "string" && origin.includes(",")) {
    origin = origin.split(",")[0].trim();
  }

  res.setHeader("Access-Control-Allow-Origin", origin);
  res.setHeader("Access-Control-Allow-Credentials", "true");
  res.status(500).json({ error: "Internal Server Error" });
});

module.exports.handler = serverless(app);

if (process.env.IS_OFFLINE || process.env.NODE_ENV === "development") {
  const port = process.env.PORT || 4000;
  app.listen(port, "127.0.0.1", () => {
    console.log(`Server running locally at http://localhost:${port}`);
  });
}
